# -*- coding: utf-8 -*-
"""
Created on Fri Apr  4 12:17:44 2025

@author: L-F-S
"""

import pandas as pd
import pickle
from conf import BASE_DIR

 # the updated map provided by Alaimo gene_map.tsv
symbol_to_id_data =pd.read_csv(BASE_DIR+'other_data/gene_map.tsv', sep='\t', dtype={'NCBI.Gene.ID':str}, usecols=[0,3])
#symbol_to_id.dropna(inplace=True)
symbol_to_id_transformed=symbol_to_id_data.set_index('Approved.symbol').to_dict()
symbol_to_id_dict=symbol_to_id_transformed['NCBI.Gene.ID']

#%%
with open(BASE_DIR+'other_data/symbol_2geneid.pkl', 'wb') as f:
    pickle.dump(symbol_to_id_dict, f)