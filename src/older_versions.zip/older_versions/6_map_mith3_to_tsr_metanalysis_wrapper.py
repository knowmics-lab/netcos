#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 21 09:41:12 2024

@ author: L-F-S
"""

#%%
from conf import MITH_OUT_DRUG
import os
import numpy as np
import subprocess


#%% Get all drugs
drugs_list=os.listdir(MITH_OUT_DRUG)

drugs_list=[x.split('.')[0] for x in drugs_list]
drugs_list=[x.split('_')[0] for x in drugs_list]
drugs_list=list(np.unique(drugs_list))

# set n of cores
cores=2

#%%
   

# get chunk size
chunk_size=int(len(drugs_list)/cores)
last_chunk_size=len(drugs_list)%cores

def get_chunk_indexes(i,chunk_size):
    i1=chunk_size*i
    i2=chunk_size*i+chunk_size
    return i1, i2

#%% 
save_csv='1'
for i in range(cores):
    i1,i2=get_chunk_indexes(i, chunk_size)
    subprocess.Popen(['python','map_mith3_drug_output_to_metanalysis_drug_wise.py',str(i1), str(i2),save_csv])

subprocess.Popen(['python','map_mith3_drug_output_to_metanalysis_drug_wise.py',str(len(drugs_list)-chunk_size),str(len(drugs_list))])

