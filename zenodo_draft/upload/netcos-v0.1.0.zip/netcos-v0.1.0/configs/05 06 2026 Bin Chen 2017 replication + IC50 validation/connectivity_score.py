#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 18 20:37:14 2025

@ author: L-F-S
calculate RGES connectivity score between disease signature and drug sinatures.

"""
import os
import sys
import numpy as np
import pandas as pd
import time
from scipy import stats
from conf import DISEASE
from loader import load_disease_signature, load_single_drug_signature

# FUNCTIONS

def get_common_genes(disease_signature, drug_signature, id_col='gene_id'):
    '''
    Identifies common items between drug and disease signature.
    Returns indexes of common items in both signatures.
    '''

    missing_items = set(disease_signature[id_col]) - set(drug_signature[id_col])
    addional_drug_items = set(drug_signature[id_col]) - set(disease_signature[id_col])
    common_items = set(disease_signature[id_col]) & set(drug_signature[id_col])

    if not len(common_items) + len(addional_drug_items) == drug_signature.shape[0]:
        raise ValueError(f'common items + additional drug items != len(drug_signature) for {id_col}')
    if not len(common_items) + len(missing_items) == disease_signature.shape[0]:
        raise ValueError(f'common items + missing drug items != len(disease_signature) for {id_col}')

    drug_common = drug_signature[drug_signature[id_col].isin(common_items)].sort_values(by=id_col)
    disease_common = disease_signature[disease_signature[id_col].isin(common_items)].sort_values(by=id_col)

    left_ids = disease_signature.loc[disease_common.index].reset_index()[id_col]
    right_ids = drug_signature.loc[drug_common.index].reset_index()[id_col]
    if not np.all(left_ids.to_numpy() == right_ids.to_numpy()):
        raise ValueError(f'common item indexes actually different between drug and disease for {id_col}!')

    return disease_common.index, drug_common.index

def get_common_genes_old(disease_signature, drug_signature):
    '''
    Identifies common genes between drug and disease signature. Returns indexes
    of common genes in both signatures.
    Input:
        - disease_signature: pd.DataFrame with columns ['gene_id', ...]
        - drug_signature: pd.DataFrame with columns ['gene_id', ...]
    Output:
        - Tuple of DataFrame.index of common genes in disease and drug signatures
    
    '''

    missing_genes=set.difference(set(disease_signature.gene_id),set(drug_signature.gene_id))
    # print('missing genes from mithril', len(missing_genes))
    addional_drug_items=set.difference(set(drug_signature.gene_id),set(disease_signature.gene_id))
    # print('addional_mith_items', len(addional_drug_items))
    
    
    common_genes=set.intersection(set(disease_signature.gene_id),set(drug_signature.gene_id))
    # print('genes in common', len(common_genes))
    if not len(common_genes)+len(addional_drug_items)==drug_signature.shape[0]:
        raise ValueError('common genes+ additional mithril items != len(mithril_gene)')
    if not len(common_genes)+len(missing_genes)==disease_signature.shape[0]:
        raise ValueError('riprova: common genes+ missing mithril items != len(DEG_genes)')

    # Get subset of signatures with common genes
    drug_common_genes_signatures=drug_signature[drug_signature['gene_id'].isin(common_genes)].sort_values(by='gene_id')
    disease_common_genes_signatures=disease_signature[disease_signature.gene_id.isin(common_genes)].sort_values(by='gene_id')
    
    if not np.unique(disease_signature.loc[disease_common_genes_signatures.index].reset_index()['gene_id']==drug_signature.loc[drug_common_genes_signatures.index].reset_index()['gene_id']):
        raise ValueError('common gene indexes actually different between drug and disease!')
    return disease_common_genes_signatures.index, drug_common_genes_signatures.index
 

def rank_genes(drug_signature, disease_signature, drug_col_name, disease_col_name, id_col='gene_id'):
    '''
    Compute the array V of sorted drug item indexes, indexed by sorted disease
    indexes.
    Input:
        - drug_signature: pd.DataFrame with columns [id_col, drug_col_name, ...]
        - disease_signature: pd.DataFrame with columns [id_col, disease_col_name, ...]
        - drug_col_name: str, column name to sort drug_signature by
        - disease_col_name: str, column name to sort disease_signature by
        - id_col: str, column name of gene IDs
     Output:
        NumPy array where the indices are sorted disease gene indexes 
        and the values are indexes of corresponding sorted drug genes.
    '''
    sorted_drug_genes = drug_signature.sort_values(by=drug_col_name, ascending=False).reset_index(drop=True)
    sorted_disease_genes = disease_signature.sort_values(by=disease_col_name)

    merged_data_on_disease_indexes = pd.merge(sorted_disease_genes,sorted_drug_genes.reset_index(), on=id_col)

    V = merged_data_on_disease_indexes['index'].to_numpy()
    return V

def compute_KS_disease_sorted(disease_disregulated_genes, V, drug_genes):
    '''
    Compute Kolmogorov-Smirnov (KS) like statistic.
    From Lamb et al., 2006 supplementary
    Input:
       - disease_disregulated_genes: list or array of gene IDs
       - V: NumPy array of drug gene indices sorted on disease indices
       - drug_genes: list or array of gene IDs in the drug signature
    Output:
       - a: float, maximum positive difference
       - b: float, maximum negative difference
       - s: int, number of disregulated genes
       - r: int, total number of genes in reference drug expression data
    '''
    # number of disregulated genes:
    s=len(disease_disregulated_genes) 

    # total number of genes in reference drug expression data:
    r=len(drug_genes)
    
    V_over_r = V/r
    a = np.max(np.arange(1, s+1)/s - V_over_r)
    b = np.max(V_over_r - (np.arange(s)/s))
    
    return a, b, s, r

def compute_KS(disease_disregulated_genes, V, drug_genes):
    '''
    Compute Kolmogorov-Smirnov (KS) statistic.
    From Lamb et al., 2006 supplementary
    Input:
       - disease_disregulated_genes: list or array of gene IDs
       - V: NumPy array of sorted drug gene indices
       - drug_genes: list or array of gene IDs in the drug signature
    Output:
       - a: float, maximum positive difference
       - b: float, maximum negative difference
       - s: int, number of disregulated genes
       - r: int, total number of genes in reference drug expression data
    '''
    V=np.sort(V)
    # number of disregulated genes:
    s=len(disease_disregulated_genes) 

    # total number of genes in reference drug expression data:
    r=len(drug_genes)
    
    V_over_r = V/r
    a = np.max(np.arange(1, s+1)/s - V_over_r)
    b = np.max(V_over_r - (np.arange(s)/s))
    
    return a, b, s, r


def compute_KS_evil_twin(disease_disregulated_genes, V, drug_genes):
    '''
    Compute Kolmogorov-Smirnov (KS) statistic.
    From Lamb et al., 2006 supplementary
    Input:
       - disease_disregulated_genes: list or array of gene IDs
       - V: NumPy array of sorted drug gene indices
       - drug_genes: list or array of gene IDs in the drug signature
    Output:
       - a: float, maximum positive difference
       - b: float, maximum negative difference
       - s: int, number of disregulated genes
       - r: int, total number of genes in reference drug expression data
    '''
    
    # number of disregulated genes:
    s=len(disease_disregulated_genes) 

    # total number of genes in reference drug expression data:
    r=len(drug_genes)
    
    V_over_r = V/r
    a = np.max(np.abs(np.arange(1, s+1)/s - V_over_r))
    b = np.max(np.abs(V_over_r - (np.arange(s)/s)))
    ks=np.max(a,b)
    
    return ks, s, r


def lamb_normalize(cs_list):
    '''
    CS normalization following Lamb et al., 2006
    Input:
        cs_list: list, connectivity scores for drugs of interest
    Output:
        list, normalized connectivity scores
    '''
    
    p=max(cs_list)
    q=min(cs_list)
    
    def extr(x):
        if x>0:
            return p
        return -q
    
    return [x/extr(x) for x in cs_list]


def calculate_CS(a_up, a_down, b_up, b_down):
    '''
    Calculate connectivity score.
    from Lamb et al., 2006
    Input:
    - a_up: float, maximum positive difference for upregulated genes
    - a_down: float, maximum positive difference for downregulated genes
    - b_up: float, maximum negative difference for upregulated genes
    - b_down: float, maximum negative difference for downregulated genes
    Output:
        - CS: float, CS value in the interval [-1, 1]
    '''
    
    if a_up>b_up:
        ks_up=a_up
    else:
        ks_up=-b_up
        
    if a_down>b_down:
        ks_down=a_down
    else:
        ks_down=-b_down
    
    if ks_up*ks_down>0:
        return 0
    return ks_up-ks_down   


def calculate_CS_evil_twin(ks_up, ks_down):
    '''
    Calculate connectivity score. But its evil twin.
    For testing
    Input:
    - a_up: float, maximum positive difference for upregulated genes
    - a_down: float, maximum positive difference for downregulated genes
    - b_up: float, maximum negative difference for upregulated genes
    - b_down: float, maximum negative difference for downregulated genes
    Output:
        - CS: float, CS value in the interval [-1, 1]
    '''
    return ks_up-ks_down 


def calculate_RGES(a_up, a_down, b_up, b_down):
    '''
    Calculate Reverse Gene Expression Score (RGES).
    from Bin Chen et al., 2017
    Input:
    - a_up: float, maximum positive difference for upregulated genes
    - a_down: float, maximum positive difference for downregulated genes
    - b_up: float, maximum negative difference for upregulated genes
    - b_down: float, maximum negative difference for downregulated genes
    Output:
        - RGES: float, RGES value in the interval [-2, 2]
    '''
    
    if a_up>b_up:
        ks_up=a_up
    else:
        ks_up=-b_up
        
    if a_down>b_down:
        ks_down=a_down
    else:
        ks_down=-b_down
    
    return ks_up-ks_down   

def montecarlo_connectivity(s_up, s_down, r, n_iterations=1000, score_type='bin_chen'):
    '''
    Randomly sample RGES
    Input:
        - s_up: int, number of upregulated genes
        - s_down: int, number of downregulated genes
        - r: int, total number of genes in reference drug expression data
        - n_iterations: int, number of Monte Carlo iterations (default: 1000)
        - score_type: str, optional, which calculation to use. 
            options: ['bin_chen', 'sirota', 'lamb'], default: 'bin_chen'
    Output:
        - list of float, sampled RGES values
    '''
    
    random_RGES_list=[]
    drug_genes=np.arange(r)
    
    for i in range(n_iterations):
        
        random_idx = np.random.choice(r, s_up + s_down, replace=False)

        random_V_up = np.sort(random_idx[:s_up])
        random_V_down = np.sort(random_idx[s_up:])
         
        # Compute random KS stats:
        random_a_up, random_b_up, _, _ = compute_KS(np.arange(s_up), random_V_up, drug_genes)
        random_a_down , random_b_down, _, _ = compute_KS(np.arange(s_down), random_V_down, drug_genes)

        # calculate RGES evil twin:
        if score_type=='evil_twin':
            ks_up,  _, _ = compute_KS(np.arange(s_up), random_V_up, drug_genes)
            ks_down, _, _ = compute_KS(np.arange(s_down), random_V_down, drug_genes)
            random_RGES_list.append(calculate_CS_evil_twin(ks_up, ks_down, random_b_up, random_b_down))
        
        # Calculate random RGES:
        if score_type=='bin_chen':
            random_RGES_list.append(calculate_RGES(random_a_up, random_a_down, random_b_up, random_b_down))
        if (score_type=='lamb') or(score_type=='sirota') :
            random_RGES_list.append(calculate_CS(random_a_up, random_a_down, random_b_up, random_b_down))

    if score_type=='lamb':
        random_RGES_list=lamb_normalize(random_RGES_list)

    return random_RGES_list


def montecarlo_connectivity_disease_sorted(s_up, s_down, r, n_iterations=1000, score_type='bin_chen'):
    '''
    Randomly sample disease-sorted RGES
    Input:
        - s_up: int, number of upregulated genes
        - s_down: int, number of downregulated genes
        - r: int, total number of genes in reference drug expression data
        - n_iterations: int, number of Monte Carlo iterations (default: 1000)
        - score_type: str, optional, which calculation to use. 
            options: ['bin_chen', 'sirota', 'lamb'], default: 'bin_chen'
    Output:
        - list of float, sampled RGES values
    '''
    
    random_RGES_list=[]
    drug_genes=np.arange(r)
    
    for i in range(n_iterations):
        
        # Generate random indexes for up and downregulated genes
        random_up_and_down_indexes=np.random.choice(r, s_up + s_down, replace=False)
         
        # Create random index dictionary:
        random_V_up=random_up_and_down_indexes[:s_up]
        random_V_down=random_up_and_down_indexes[-s_down:]
        
        # Compute random KS stats:
        random_a_up, random_b_up, _, _ = compute_KS_disease_sorted(random_up_and_down_indexes[:s_up], random_V_up, drug_genes)
        random_a_down , random_b_down, _, _ = compute_KS_disease_sorted(random_up_and_down_indexes[-s_down:], random_V_down, drug_genes)

        # calculate RGES evil twin:
        if score_type=='evil_twin':
            ks_up,  _, _ = compute_KS_disease_sorted(random_up_and_down_indexes[:s_up], random_V_up, drug_genes)
            ks_down, _, _ = compute_KS_disease_sorted(random_up_and_down_indexes[-s_down:], random_V_down, drug_genes)
            random_RGES_list.append(calculate_CS_evil_twin(ks_up, ks_down, random_b_up, random_b_down))
        
        # Calculate random RGES:
        if score_type=='bin_chen':
            random_RGES_list.append(calculate_RGES(random_a_up, random_a_down, random_b_up, random_b_down))
        if (score_type=='lamb') or(score_type=='sirota') :
            random_RGES_list.append(calculate_CS(random_a_up, random_a_down, random_b_up, random_b_down))

    if score_type=='lamb':
        random_RGES_list=lamb_normalize(random_RGES_list)

    return random_RGES_list

def random_disease_bin_chen_connectivity(drug_signature, rank_on='magnitude', id_col='gene_id'):
    '''temp
    calculates the Reverse Gene Expression Score (RGES), a
   connectivity score, as defined in Bin, Chen, 2017, of a drug signature versus
   a random genes  ranking
    Input:
        - drug_signature: pd.DataFrame with columns ['gene_id', signature data, p value]
        - rank_on: str ranking column. default='magnitude' 
                options: {'p_value', 'magnitude'}. Do not change unless you
                know what you're doing'
                    
    Output:
        -   measured_RGES: float, calculated RGES value
        -   p_value: float, p-value from Monte Carlo simulation
    '''
    
    
    if rank_on=='p_value':
        ranking_col_name=drug_signature.columns[2]
    if rank_on=='magnitude':
        ranking_col_name=drug_signature.columns[1]
    
    # generate random up and down regulated disease genes
    r= drug_signature.shape[0]
    l=np.random.randint(1,r)
    s_up = r-l
    s_down = l
    gene_id_list = drug_signature[id_col]
    shuffled_gene_ids = gene_id_list[np.random.choice(gene_id_list.index, len(gene_id_list), replace=False)]
    random_disease_up = shuffled_gene_ids[:s_up]
    random_disease_down = shuffled_gene_ids[-s_down:]
     
    # Calculate rank map V for up and down regulated genes:
    V_up = rank_genes(drug_signature, pd.DataFrame({id_col: random_disease_up})  , ranking_col_name, id_col, id_col=id_col)
    V_down = rank_genes(drug_signature, pd.DataFrame({id_col: random_disease_down}), ranking_col_name, id_col, id_col=id_col)
    
    # Compute random KS stats:
    a_up, b_up, _, _ = compute_KS(random_disease_up, V_up, drug_signature[id_col])
    a_down , b_down, _, _ = compute_KS(random_disease_down, V_down, drug_signature[id_col])
    
    # Compute RGES:
    measured_RGES_for_random_disease = calculate_RGES(a_up, a_down, b_up, b_down)
    
    return measured_RGES_for_random_disease


def bin_chen_connectivity(disease_signature, drug_signature, rank_on='magnitude', id_col='gene_id',\
    drug_ranking_col_name=None, disease_ranking_col_name=None):
    '''
    calculates the Reverse Gene Expression Score (RGES), a
   connectivity score, as defined in Bin, Chen, 2017
    Input:
        - disease_signature: pd.DataFrame with columns ['gene_id', signature data, p value]
        - drug_signature: pd.DataFrame with columns ['gene_id', signature data, p value]
        - rank_on: str ranking column. default='magnitude' 
                options: {'p_value', 'magnitude'}. Do not change unless you
                know what you're doing'
                    
    Output:
        -   measured_RGES: float, calculated RGES value
        -   p_value: float, p-value from Monte Carlo simulation
    '''
    
    if drug_ranking_col_name is None or disease_ranking_col_name is None:
        if rank_on=='p_value':
            drug_ranking_col_name=drug_signature.columns[2]
            disease_ranking_col_name=disease_signature.columns[2]
        if rank_on=='magnitude':
            drug_ranking_col_name=drug_signature.columns[1]
            disease_ranking_col_name=disease_signature.columns[1]
    
    # # Get lists of up (down) regulated genes: older with 2vs
    disease_signature_up = disease_signature[disease_signature[disease_ranking_col_name]>0]
    disease_signature_down = disease_signature[disease_signature[disease_ranking_col_name]<0]
    
    # Calculate rank map V for up and down regulated genes:
    V_up = rank_genes(drug_signature, disease_signature_up, drug_ranking_col_name, disease_ranking_col_name, id_col=id_col)
    V_down = rank_genes(drug_signature, disease_signature_down, drug_ranking_col_name, disease_ranking_col_name, id_col=id_col)
    
    # Compute KS statistic for up and down regulated genes:
    a_up, b_up, s_up, r = compute_KS(disease_signature_up[id_col], V_up, drug_signature[id_col])
    a_down , b_down, s_down, r = compute_KS(disease_signature_down[id_col], V_down, drug_signature[id_col])
    
    # Compute RGES:
    measured_RGES = calculate_RGES(a_up, a_down, b_up, b_down)
    
    # Calculate two tailed p-value (no assumption on the direction of RGES 
    # between disease and drug) for measured RGES, using random sampling:
    n_iterations=1000 
    random_RGES_list = montecarlo_connectivity(s_up, s_down, r, n_iterations, score_type='bin_chen')
    p_value=np.sum(np.abs(np.array(random_RGES_list))>np.abs(measured_RGES))/n_iterations
    return measured_RGES, p_value

def bin_chen_connectivity_sorted(disease_signature, drug_signature, rank_on='magnitude', id_col='gene_id',\
    drug_ranking_col_name=None,    disease_ranking_col_name=None):
    '''
    calculates the Reverse Gene Expression Score (RGES), a
   connectivity score, as defined in Bin, Chen, 2017
    Input:
        - disease_signature: pd.DataFrame with columns ['gene_id', signature data, p value]
        - drug_signature: pd.DataFrame with columns ['gene_id', signature data, p value]
        - rank_on: str ranking column. default='magnitude' 
                options: {'p_value', 'magnitude'}. Do not change unless you
                know what you're doing'
                    
    Output:
        -   measured_RGES: float, calculated RGES value
        -   p_value: float, p-value from Monte Carlo simulation
    '''
    
    if drug_ranking_col_name is None or disease_ranking_col_name is None:
        if rank_on=='p_value':
            drug_ranking_col_name=drug_signature.columns[2]
            disease_ranking_col_name=disease_signature.columns[2]
        if rank_on=='magnitude':
            drug_ranking_col_name=drug_signature.columns[1]
            disease_ranking_col_name=disease_signature.columns[1]
    
    # # Get lists of up (down) regulated genes: older with 2vs
    disease_signature_up = disease_signature[disease_signature[disease_ranking_col_name]>0]
    disease_signature_down = disease_signature[disease_signature[disease_ranking_col_name]<0]
    
    # Calculate rank map V for up and down regulated genes:
    V_up = rank_genes(drug_signature, disease_signature_up, drug_ranking_col_name, disease_ranking_col_name, id_col=id_col)
    V_down = rank_genes(drug_signature, disease_signature_down, drug_ranking_col_name, disease_ranking_col_name, id_col=id_col)
    
    # Compute KS statistic for up and down regulated genes:
    a_up, b_up, s_up, r = compute_KS_disease_sorted(disease_signature_up[id_col], V_up, drug_signature[id_col])
    a_down , b_down, s_down, r = compute_KS_disease_sorted(disease_signature_down[id_col], V_down, drug_signature[id_col])
    
    # Compute RGES:
    measured_RGES = calculate_RGES(a_up, a_down, b_up, b_down)
    
    # Calculate two tailed p-value (no assumption on the direction of RGES 
    # between disease and drug) for measured RGES, using random sampling:
    n_iterations=1000 
    random_RGES_list = montecarlo_connectivity(s_up, s_down, r, n_iterations, score_type='bin_chen')
    p_value=np.sum(np.abs(np.array(random_RGES_list))>np.abs(measured_RGES))/n_iterations
    return measured_RGES, p_value

calc_connectivity_score_with = {"bin_chen":bin_chen_connectivity, "bin_chen_disease_sorted":bin_chen_connectivity_sorted, "lamb":"TODO: implement me!"}
